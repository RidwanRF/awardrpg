Resource name: Bokeh Depth of Field 0.0.5
Uses: Ring DOF(Petka/martinsh) from reshade MasterEffect ReBorn 1.1.287
Link: http://reshade.me/forum/shaderpack-mastereffect/161-mastereffect-reborn-official-thread
Converted by: Ren712
Contact: knoblauch700@o2.pl

Original description:

To explain this better, think about what happens if you hold your finger in front of your 
face and focus on it. What happens? The finger is sharp, the background is blurred. 
If you now focus on the background, the finger gets blurred. That's the base of theDOF shader, 
it blurs the foreground if the focus point (by default screen center) looks at something 
in the depth and the other way round. Bokeh means that bright sources are highlighted, a 
christmas tree without bokeh would look like a green mash, but here are the bright pixels 
highlighted with a circular shape.

Additional description:
Toggle the effect with /sBokeh
The effect requires Shader Model 3.0 graphics card and depth buffer support.


