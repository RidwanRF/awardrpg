--
-- c_switch.lua
--

----------------------------------------------------------------
----------------------------------------------------------------
-- Effect switching on and off
--
--	To switch on:
--			triggerEvent( "switchDoFBokeh", root, true )
--
--	To switch off:
--			triggerEvent( "switchDoFBokeh", root, false )
--
----------------------------------------------------------------
----------------------------------------------------------------

--------------------------------
-- onClientResourceStart
--		Auto switch on at start
--------------------------------
--[[addEventHandler( "onClientResourceStart", getResourceRootElement( getThisResource()),
	function()
		if (vCardPSVer()~="3") then outputChatBox('DoFBokeh: Shader Model 3 not supported',255,0,0) return end
		if not isDepthBufferAccessible() then outputChatBox('DoFBokeh: Depth Buffer not supported',255,0,0) return end
		triggerEvent( "switchDoFBokeh", resourceRoot, 0 )
		addCommandHandler( "sBokeh",
			function()
				triggerEvent( "switchDoFBokeh", resourceRoot, not bEffectEnabled )
			end
		)
	end
)]]


--------------------------------
-- Switch effect on or off
--------------------------------
function switchDoFBokeh( aaOn )
	outputDebugString( "switchDoFBokeh: " .. tostring(aaOn) )
	if aaOn then
		enableDoFBokeh()
	else
		disableDoFBokeh()
	end
end

addEvent( "switchDoFBokeh", true )
addEventHandler( "switchDoFBokeh", resourceRoot, switchDoFBokeh )
