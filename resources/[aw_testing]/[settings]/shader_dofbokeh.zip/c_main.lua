--
-- c_main.lua
--
local orderPriority = "-2.7"	-- The lower this number, the later the effect is applied

Settings = {}
Settings.var = {}

---------------------------------
-- Settings for effect
---------------------------------
function setEffectVariables()
    local v = Settings.var
	-- CoC 
	v.fManualFocus = false
	v.fNearBlurCurve = 10.0 -- [0.4 to X] Power of blur of closer-than-focus areas.
	v.fFarBlurCurve = 0.5 -- [0.4 to X] Elementary, my dear Watson: Blur power of areas behind focus plane.
	v.fManualFocusDepth = 0.1 -- [0.0 to 1.0] Manual focus depth. 0.0 means camera is focus plane, 1.0 means sky is focus plane.
    -- Dof1Pass
	v.fRingDOFFringe = 0.5 -- [0.0 to 1.0] Amount of chromatic abberation
	v.fBlurRadius = 4.0	-- [5.0 to 50.0] Blur radius approximately in pixels. Radius, not diameter.
    -- Dof2Pass
	v.fBlurRadius = 4.0 -- [5.0 to 50.0] Blur radius approximately in pixels. Radius, not diameter.
	v.fRingDOFThreshold = 2.5 -- [0.8 to 2.0] Threshold for bokeh brightening. Above this value, everything gets much much brighter. 1.0 is maximum value for LDR games like GTASA, higher values work only on HDR games like Skyrim etc.
	v.fRingDOFGain = 0.1 -- [0.1 to 2.0] Amount of brightening for pixels brighter than threshold.
-- You'll need to edit that yourself - look in the DOF1 and DOF2 shader files
--#define iRingDOFRings   		4  	//[1 to 8] Ring count
--#define iRingDOFSamples   		6  	//[5 to 30] Samples on the first ring. The other rings around have more samples
--#define fRingDOFBias    		0.0 	//[0.1 to 2.0] bokeh bias.
end

---------------------------------
-- shader model version
---------------------------------
function vCardPSVer()
	local smVersion = tostring(dxGetStatus().VideoCardPSVersion)
	outputDebugString("VideoCardPSVersion: "..smVersion)
	return smVersion
end

---------------------------------
-- DepthBuffer access
---------------------------------
function isDepthBufferAccessible()
	local depthStatus = tostring(dxGetStatus().DepthBufferFormat)
	outputDebugString("DepthBufferFormat: "..depthStatus)
	if depthStatus=='unknown' then depthStatus=false end
	return depthStatus
end

----------------------------------------------------------------
-- enableDoFBokeh
----------------------------------------------------------------
function enableDoFBokeh()
	if bEffectEnabled then return end
	-- Create things
	myScreenSource = dxCreateScreenSource( scx, scy )
	
	dRingDOF1Shader,tecName = dxCreateShader( "fx/dRingDOF1.fx" )
	outputDebugString( "blurHShader is using technique " .. tostring(tecName) )

	dRingDOF2Shader,tecName = dxCreateShader( "fx/dRingDOF2.fx" )
	outputDebugString( "blurVShader is using technique " .. tostring(tecName) )
	
	dCoCShader,tecName = dxCreateShader( "fx/dCoC.fx" )
	outputDebugString( "depthTexShader is using technique " .. tostring(tecName) )
	
	-- Get list of all elements used
	effectParts = {
						myScreenSource,
						dRingDOF1Shader,
						dRingDOF2Shader,
						dCoCShader,
					}

	-- Check list of all elements used
	bAllValid = true
	for _,part in ipairs(effectParts) do
		bAllValid = part and bAllValid
	end
	
	setEffectVariables ()
	bEffectEnabled = true
	
	if not bAllValid then
		outputChatBox( "DoF: Could not create some things. Please use debugscript 3" )
		disableDoFBokeh()
	else

    local v = Settings.var
	
	dxSetShaderValue( dCoCShader,"fManualFocus", v.fManualFocus )
	dxSetShaderValue( dCoCShader,"fNearBlurCurve", v.fNearBlurCurve )
	dxSetShaderValue( dCoCShader,"fFarBlurCurve", v.fFarBlurCurve )
	dxSetShaderValue( dCoCShader,"fManualFocusDepth", v.fManualFocusDepth )
	dxSetShaderValue( dRingDOF1Shader, "fRingDOFFringe", v.fRingDOFFringe )
	dxSetShaderValue( dRingDOF1Shader, "fBlurRadius", v.fBlurRadius )
	dxSetShaderValue( dRingDOF2Shader, "fBlurRadius", v.fBlurRadius )
	dxSetShaderValue( dRingDOF2Shader, "fRingDOFThreshold", v.fRingDOFThreshold )
	dxSetShaderValue( dRingDOF2Shader, "fRingDOFGain", v.fRingDOFGain )
	end	
end

----------------------------------------------------------------
-- disableDoFBokeh
----------------------------------------------------------------
function disableDoFBokeh()
	if not bEffectEnabled then return end
	-- Destroy all shaders
	for _,part in ipairs(effectParts) do
		if part then
			destroyElement( part )
		end
	end
	effectParts = {}

	bAllValid = false
	RTPool.clear()
	
	-- Flag effect as stopped
	bEffectEnabled = false
end

-----------------------------------------------------------------------------------
-- onClientHUDRender
-----------------------------------------------------------------------------------
addEventHandler( "onClientHUDRender", root,
    function()
			if not bAllValid or not Settings.var then return end
			local v = Settings.var	
			-- Reset render target pool
			RTPool.frameStart()
			-- Update screen
			dxUpdateScreenSource( myScreenSource, true )
			-- Start with screen
			local current = myScreenSource

			-- Apply all the effects, bouncing from one render target to another
			local depthTex = getDepthTexture( current )
			current = applyRing1( current,depthTex )
			current = applyRing2( current,depthTex )

			-- When we're done, turn the render target back to default
			dxSetRenderTarget()
			
			if current then dxDrawImage( 0, 0, scx, scy, current, 0, 0, 0, tocolor(255,255,255,255) ) end
			--if depthTex then dxDrawImage( 0.75*scx, 0, scx/4, scy/4, depthTex, 0, 0, 0, tocolor(255,255,255,255) ) end
		end
,true ,"low" .. orderPriority )

-----------------------------------------------------------------------------------
-- Apply the different stages
-----------------------------------------------------------------------------------
function getDepthTexture(Src) 
	if not Src then return nil end
	local mx,my = dxGetMaterialSize( Src )
	local newRT = RTPool.GetUnused( mx,my )
	if not newRT then return nil end
	dxSetRenderTarget( newRT, true ) 
	dxSetShaderValue( dCoCShader, "sTexSize", mx,my )
	dxDrawImage( 0, 0, mx, my, dCoCShader )
	return newRT
end
	
function applyRing1(Src, getDepth)
	if not Src then return nil end
	local mx,my = dxGetMaterialSize( Src )
	local newRT = RTPool.GetUnused(mx,my)
	if not newRT then return nil end
	dxSetRenderTarget( newRT, true ) 
	dxSetShaderValue( dRingDOF1Shader, "sTexColor", Src )
	dxSetShaderValue( dRingDOF1Shader, "sTexCoC", getDepth )
	dxSetShaderValue( dRingDOF1Shader, "sTexSize", mx,my )
	dxDrawImage( 0, 0, mx, my, dRingDOF1Shader )
	return newRT
end

function applyRing2(Src, getDepth)
	if not Src then return nil end
	local mx,my = dxGetMaterialSize( Src )
	local newRT = RTPool.GetUnused(mx,my)
	if not newRT then return nil end
	dxSetRenderTarget( newRT, true ) 
	dxSetShaderValue( dRingDOF2Shader, "sTexColor", Src )
	dxSetShaderValue( dRingDOF2Shader, "sTexCoC", getDepth )
	dxSetShaderValue( dRingDOF2Shader, "sTexSize", mx,my )
	dxDrawImage( 0, 0, mx, my, dRingDOF2Shader )
	return newRT
end

----------------------------------------------------------------
-- Avoid errors messages when memory is low
----------------------------------------------------------------
_dxDrawImage = dxDrawImage
function xdxDrawImage(posX, posY, width, height, image, ... )
	if not image then return false end
	return _dxDrawImage( posX, posY, width, height, image, ... )
end